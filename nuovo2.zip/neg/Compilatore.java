package neg;

import java.io.*;
import javax.swing.*;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Compilatore{
    static String alfabeto = " ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.+-*/=!&;:()[]_<>%"+'\t'+'"';
    static String[] dizionario = {
          "if", "let", "print", "else", "input", "goto", "etq"
    };
    static String[] etichette;
    static ListaVar variabili;
    static JTextArea errArea;
    static JTextArea outArea;
    static String outString;
    static Variabile v;
    public static boolean controlloSintattico(String s, String[] diz){
        for(int j=0;j<diz.length;j++){
            if(s.equals(diz[j])){
                return true;
            }
        }
        return false;
    }
    public static void ElevaErr(int riga, int colonna, String err) throws Err{
        throw new Err("Errore: " + err + ", riga: " + riga + ", colonna: " + colonna);
    }
    public static void controlloErrori(String righe[]) throws Err{
        for(int i=0;i<righe.length;i++){
            boolean inizioStringa = false;
            int inizio = 0;
            if(!righe[i].startsWith("//")){
                for(int j=0;j<righe[i].length();j++){
                    char carattere = righe[i].charAt(j);
                    if(carattere == '"'){
                        inizioStringa = !inizioStringa;
                        inizio=j;
                    }
                    if(!inizioStringa){
                        if(alfabeto.indexOf(carattere) == -1){
                            ElevaErr(i+1, j+1, "Carattere non riconosciuto: '" + carattere + "'");
                        }
                    }
                    if(j == righe[i].length()-1 && inizioStringa)
                        ElevaErr(i+1, inizio+1, "Stringa non terminata");
                }
            }
        }
    }
    
    public static void aggiungiDizio(String s, String[] di){
        String[] nuovoDizionario = new String[dizionario.length + 1];
        System.arraycopy(di, 0, nuovoDizionario, 0, di.length);
        nuovoDizionario[di.length] = s;
        di = nuovoDizionario;
    }
    
    public static String estraiBlocco(String codice) throws Err{
        String startMarker = "INIZIO";
        String endMarker = "FINE";

        int startIndex = codice.indexOf(startMarker);
        int endIndex = codice.indexOf(endMarker);

        if (startIndex == -1) {
            ElevaErr(0,0,"manca INIZIO");
        }
        if (endIndex == -1) {
            ElevaErr(0,0,"manca FINE");
        }
        if (endIndex <= startIndex) {
            ElevaErr(0,0,"FINE prima di INIZIO");
        }

        return codice.substring(startIndex+6, endIndex).trim();
    }
    
    public static int getRigaEtq(String s, String etq) {
    String[] righe = s.split(";");
    for (int i = 0; i < righe.length; i++) {
        String[] parole = righe[i].trim().split("\\s+");
        if (parole.length > 1 && parole[1].equals(etq)) {
            return i;
        }
    }
    return -1;
}
public static int getRigaEtq(String s, String etq, int riga) {
    String[] righe = s.split(";");
    for (int i = 0; i < righe.length; i++) {
        String[] parole = righe[i].trim().split("\\s+");
        if (parole.length > 1 && parole[0].equals("etq") && parole[1].equals(etq) && i != riga) {
            return i;
        }
    }
    return -1;
}

    
    public static void compila(String s, JTextArea errAreas, JTextArea outAreas, String outStrings){
        
        variabili = new ListaVar();
        int livello_corrente = 0;
        Variabile v;
        int livello;
        
        try{
            s = estraiBlocco(s);
            errArea = errAreas;
            outArea = outAreas;
            outString = outStrings;
            String[] righe = s.replace("\n","").split(";");
            controlloErrori(righe);
            Funzioni.trasformaElse(righe);
            for(int i=0;i<righe.length;i++){
                livello = Funzioni.getLivello(righe[i]);
                //System.out.println("livello: " + Funzioni.getLivello(righe[i]));
                //System.out.println("Livello corrente: " + livello_corrente);
                /*if(livello_corrente != livello){
                    while(Funzioni.getLivello(righe[i]) != livello_corrente && i < righe.length)
                        i+=1;
                }*/
                if(livello < livello_corrente){
                    livello_corrente = livello;
                }
                String tokens[] = Funzioni.modificaString(righe[i].trim(), ' ', '#').split(" ");
                if(righe[i].startsWith("//"))
                    continue;
                switch(tokens[0]){
                    case "etq":
                        if(tokens.length != 2)
                            ElevaErr(i+1, 0, "Sintassi etq sbagliata");
                        //System.out.println("jnscainasinciasi" + getRigaEtq(s,tokens[1],i));
                        if(getRigaEtq(s,tokens[1],i) != -1)
                            ElevaErr(i+1, 0, "Etichetta già esistente");
                        break;
                    case "input":
                        if(tokens.length != 3)
                            ElevaErr(i+1, 0, "Sintassi input sbagliata");
                        if(getVar(tokens[1]) == null)
                            ElevaErr(i+1, 0, "Variabile non dichiarata");
                        String in = JOptionPane.showInputDialog(null, tokens[2]);
                        if (in == null) {
                            modificaVar(getVar(tokens[1]), new Variabile(tokens[1],3,"null"));
                        } else {
                            modificaVar(getVar(tokens[1]), new Variabile(tokens[1],in));
                        }
                        break;
                    case "let":
                        if(getVar(tokens[1]) != null)
                            ElevaErr(i+1, 0, "Variabile già dichiarata: " + tokens[1]);
                        dichiara(tokens, i, righe[i], 0);
                        aggiungiDizio(tokens[1], dizionario);
                        break;
                    case "print":
                        String param = tokens[1];
                        System.out.println("ciao");
                        if (param.charAt(0) == '"') {
                            Funzioni.printOut(Funzioni.modificaString2(param.substring(1, param.length()-1), '#', ' '));
                        } else if (param.charAt(0) == '(') 
                        {
                            param = righe[i].substring(righe[i].indexOf("print (")+7, righe[i].length()-1);
                            StringBuilder p = new StringBuilder();
                            boolean trovata = false;
                            for(int h=0;h<param.length();h++){
                                if(param.charAt(h) == '"')
                                    trovata = !trovata;
                                
                                if(trovata){
                                    p.append(param.charAt(h));
                                } else {
                                    if(param.charAt(h) != ' ')
                                        p.append(param.charAt(h));
                                }
                            }
                            param = p.toString();
                            //System.out.println(param);
                            String[] tokens_print = param.split("\\+");
                            String stringa = "";
                            for (int z = 0; z < tokens_print.length; z++) {
                                //System.out.println("token: " + tokens_print[z]);
                                if (tokens_print[z].charAt(0) == '"') {
                                    stringa += Funzioni.modificaString2(tokens_print[z].substring(1, tokens_print[z].length()-1),'#',' ');
                                } else {
                                    String str = Funzioni.converti(getVar(tokens_print[z]));
                                    if (str == null)
                                        ElevaErr(i + 1, 0, "La variabile " + tokens_print[z] + " non esiste");
                                    stringa += Funzioni.modificaString2(str, '#', ' ');
                                }
                            }
                            Funzioni.printOut(stringa);
                        }else{
                            System.out.println("dskajbisad " + param);
                            String str = Funzioni.converti(getVar(param));
                            
                            System.out.println(getVar(param).toString());
                            if(str == null)
                                ElevaErr(i+1, 0, "La variabile " + param + " non esiste");
                            Funzioni.printOut(Funzioni.modificaString(str, '#', ' '));
                        }
                        break;
                    case "else":
                        ElevaErr(i+1, 0, "Else non previsto");
                        break;
                    case "goto":
                        if(tokens.length != 2)
                            ElevaErr(i+1, 0, "Sintassi goto sbagliata");
                        i = getRigaEtq(s,tokens[1]);
                        //System.out.println("asdjnasijnd"+i);
                        if(i == -1)
                            ElevaErr(i+1,0,"Etichetta non esistente");
                        livello_corrente = Funzioni.getLivello(righe[i]);
                        i = i-1;
                        //System.out.println("riga: " + i);
                        //System.out.println("GOTO A " + i+1);
                        
                        break;
                    case "if": // if a > b
                        Variabile v1, v2;
                        v1 = creaVar(tokens[1]);
                        v2 = creaVar(tokens[3]);
                        //System.out.println("v2 " + tokens[3]);
                        String ope = tokens[2];
                        //System.out.println("tipo1: "+ v1.tipo + ", tipo2: " + v2.tipo);
                        
                        if(v1.tipo != v2.tipo)
                            ElevaErr(i+1, 0, "I tipi dei dati da confrontare devono essere gli stessi");
                        
                        switch(ope){
                            case ">":
                            case "<":
                            case ">=":
                            case "<=":
                                if(v1.tipo == 3)
                                    ElevaErr(i+1, 0, "Una stringa non può accettare questo operatore nel confronto");
                                break;
                        }
                        switch(ope){
                            case ">":
                                if(Funzioni.getNumero(v1) > Funzioni.getNumero(v2))
                                    livello_corrente+=1;
                                break;
                            case "<":
                                if(Funzioni.getNumero(v1) < Funzioni.getNumero(v2))
                                    livello_corrente+=1;
                                break;
                            case ">=":
                                if(Funzioni.getNumero(v1) >= Funzioni.getNumero(v2))
                                    livello_corrente+=1;
                                break;
                            case "<=":
                                if(Funzioni.getNumero(v1) <= Funzioni.getNumero(v2))
                                    livello_corrente+=1;
                                break;
                            case "==":
                                if(Funzioni.getNumero(v1) == Funzioni.getNumero(v2))
                                    livello_corrente+=1;
                                break;
                            case "!=":
                                if(Funzioni.getNumero(v1) != Funzioni.getNumero(v2))
                                    livello_corrente+=1;
                                break;
                        }
                        
                        if(livello_corrente == livello){
                            i+=1;
                            while(i < righe.length && Funzioni.getLivello(righe[i]) != livello_corrente){
                                i+=1;
                                if(i < righe.length && Funzioni.getLivello(righe[i]) < livello_corrente){
                                    livello_corrente-=1;
                                }
                            }
                            i-=1;
                        }
                        break;
                    default:
                        if((v = getVar(tokens[0])) != null){
                            dichiara(tokens, i, righe[i], 1);
                        } else
                            ElevaErr(i+1,0,"token non riconosciuto");
                        break;
                }
            }
        } catch(Err e){
            Funzioni.printError(e);
        }
    }
    
    static Variabile creaVar(String s){
        Variabile v;
        if((v = getVar(s)) == null){
            int tipo = Funzioni.getTipo(s);
            switch(tipo){
                case 1:
                    return new Variabile("",tipo,Integer.parseInt(s));
                case 2:
                    return new Variabile("",tipo,Double.parseDouble(s));
                case 3:
                    return new Variabile("",tipo,s);
            }
        }else
            return v;
        return null;
    }
    public static Variabile getVar(String s){
        //variabili.stampa();
        Variabile v = variabili.testa;
        while(v != null){
            System.out.println("V: " + v.toString());
            if(v.nome.equals(s)){
                return v;
            }
            v = v.next;
        }
        return null;
    }
    
    public static void modificaVar(Variabile s, Variabile d) {
    Variabile v = variabili.testa;
    if (v == s) {
        d.next = s.next;
        variabili.testa = d;
        return;
    }

    while (v != null && v.next != null) {
        if (v.next == s) {
            d.next = s.next;
            v.next = d;
            break;
        }
        v = v.next;
    }
}

    
    public static void dichiara(String[] tokens, int riga, String r, int q) throws Err{
        if(tokens.length == 2){
            variabili.push(new Variabile(tokens[1], 3, "null"));
            return;
        }
        if(tokens.length < 4 - q || !tokens[2 - q].equals("=")) {
            ElevaErr(riga + 1, 0, "Dichiarazione non valida");
            return;
        }
        
        String nomeVar = tokens[1 - q];
        String valoreStr = r.substring(r.indexOf("=") + 1).trim();
        int tipo = Funzioni.getTipo(valoreStr);
        
        Variabile nuovaVar;
        
        switch(tipo) {
            case 1: // Intero
                nuovaVar = new Variabile(nomeVar, tipo, Integer.parseInt(valoreStr));
                break;
            case 2: // Float
                nuovaVar = new Variabile(nomeVar, tipo, Float.parseFloat(valoreStr));
                break;
            case 3: // Stringa o espressione
                if (valoreStr.startsWith("\"") && valoreStr.endsWith("\"")) {
                    nuovaVar = new Variabile(nomeVar, tipo, valoreStr.substring(1,valoreStr.length()-1));
                } else {
                    double risultato = Funzioni_calc.main(valoreStr, riga);
                    tipo = (risultato == (int) risultato) ? 1 : 2;
                    nuovaVar = new Variabile(nomeVar, tipo, (tipo == 1) ? (int) risultato : risultato);
                }
                break;
            default:
                ElevaErr(riga + 1, 0, "Tipo di valore non supportato");
                return;
        }
        
        System.out.println(nuovaVar.toString() + " q: " + q);
        
        if (q == 0){
            variabili.push(nuovaVar);
            
        }else{
            modificaVar(getVar(nomeVar), nuovaVar);
            variabili.stampa();
        }
    }
    
    /*public static void compila() throws IOException{
        FileReader f = new FileReader("./codice.wow7");
        BufferedReader r = new BufferedReader(f);
        String codice = "";
        String riga;
        while((riga = r.readLine()) != null){
            codice += riga + "\n";
        }
        controlloErrori(codice);
    }*/
}
